using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CollageAdmission3
{
    public enum AdmissionProcess{Default,Admitted,cancelled}
    public class AdmissionDetails
    {
        private static int s_admissionId=1000;
        public string AdmissionId{get; set;}
        public string StudentId{get; set;}

        public string DepartmentId{get; set;}

        public DateTime AdmissionDate{get; set;}

        public AdmissionProcess AdmissionStatus{get; set;}


        public AdmissionDetails(string studentId,string departmentId,DateTime admissionDate,AdmissionProcess admissionStatus)
        {
            s_admissionId++;
            AdmissionId="AID"+s_admissionId;
            AdmissionDate=admissionDate;
            AdmissionStatus=admissionStatus;

        }

        
 }

     
    }
