﻿using System;
using System.Collections.Generic;
namespace CollageAdmission3;
class Program{
    public static void Main(string[] args)
    {
       Operation.Default();
       Operation.MainMenu();
        
    }
}
